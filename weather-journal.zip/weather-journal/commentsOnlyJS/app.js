// Create a new date instance dynamically with JS
let d = new Date();
//let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();

// Personal API Key for OpenWeatherMap API
let URL = `http://api.openweathermap.org/data/2.5/forecast?id=`; //?zip
let apikey = '&appid=5435cb1a58a2bf7d1e2eb554f75c101e';


// Event listener to add function to existing HTML DOM element
document.getElementById('generate').addEventListener('click', performAction);

/* Function called by event listener */
function performAction(s) {
    const newId = document.getElementById('id').value;
    const feeling = document.getElementBtId('feeling').value;
    getWeather(URL, newId, apikey)
        .then(function (data) {
            console.log(data);
            //Add data to POST request
            postData('/add'. {
                date: d,
                temp: data.list[0].main.temp,
                content: feeling
            })
            updateUI();
        })
};

/* Function to GET Web API Data*/
const getWeather = async (URL, id, key) => {
    const res = await fetch(URL + id + key)
    try {
        const data = await res.json();
        return data;
    } catch (error) {
        console.log("error", error)
        //appropriately handlethe error
    }
}

/* Function to POST data */
const postData = async (url = '', data = {}) => {
    console.log(data);
    const responce = await fetch(url, {
        method = 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
        },
        //body data type must match "Content-Type" header
        body: JSON.stringify(data) //Create JSON string from Javascript object
    });
    try {
        const newData = await response.json();
        console.log(newData);
        return newData;
    } catch (error) {
        console.log("error", error);
    }
}


/* Function to GET Project Data */
const updateUI = async () => {
    const request = await fetch('/all');
    try {
        const allData = await request.json();
        document.getElementById('date').innerHTML = `Date: ${allData[0].date}`;
        document.getElementById('temp').innerHTML = `Temperature: ${allData[0].temp}`;
        document.getElementById('content').innerHTML = `I feel: ${allData[0].content}`;
    } catch (error) {
        console.log("error", error);
    }
}